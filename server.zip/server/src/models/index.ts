// models/index.ts
import { Sequelize } from 'sequelize';
import { User as UserClass, UserFactory } from './user.js';
import { Ticket as TicketClass, TicketFactory } from './ticket.js';
import dotenv from 'dotenv';

dotenv.config();
const sequelize = new Sequelize(process.env.DB_URL!, {
  dialect: 'postgres', // or your dialect
  // ...other options
});

// Initialize models
const User = UserFactory(sequelize);
const Ticket = TicketFactory(sequelize);

// Associations
Ticket.belongsTo(User, { foreignKey: 'assignedUserId', as: 'assignedUser' });
User.hasMany(Ticket, { foreignKey: 'assignedUserId', as: 'tickets' });

export { sequelize, User, Ticket };
export default sequelize;
