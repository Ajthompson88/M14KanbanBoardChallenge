import { DataTypes, Sequelize, Model, Optional, InferAttributes, InferCreationAttributes, CreationOptional } from 'sequelize';
import bcrypt from 'bcrypt';

/** Strong, explicit attributes (safe to expand later) */
export interface UserAttributes {
  id: number;
  username: string;
  password: string; // hashed at rest
}

export interface UserCreationAttributes extends Optional<UserAttributes, 'id'> {}

/** Instance type with helper methods */
export class User extends Model<InferAttributes<User>, InferCreationAttributes<User>> {
  declare id: CreationOptional<number>;
  declare username: string;
  declare password: string;

  /** Compare a plaintext password to the stored hash */
  public async comparePassword(plain: string): Promise<boolean> {
    return bcrypt.compare(plain, this.password);
  }

  /** Hash the password (used by hooks) */
  public async setPassword(plain: string) {
    const saltRounds = 10;
    this.password = await bcrypt.hash(plain, saltRounds);
  }

  /** Hide sensitive fields by default when serializing */
  public toJSON(): Omit<UserAttributes, 'password'> & { id: number } {
    const values = { ...this.get() } as any;
    delete values.password;
    return values;
  }
}

export function UserFactory(sequelize: Sequelize): typeof User {
  User.init(
    {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      username: {
        type: DataTypes.STRING(100),
        allowNull: false,
        unique: true,
        validate: {
          notEmpty: true,
          len: [3, 100],
        },
      },
      password: {
        type: DataTypes.STRING(72), // bcrypt max effective length
        allowNull: false,
        validate: {
          notEmpty: true,
        },
      },
    },
    {
      tableName: 'users',
      sequelize,
      defaultScope: {
        attributes: { exclude: ['password'] },
      },
      hooks: {
        /** Hash on create */
        beforeCreate: async (user: User) => {
          await user.setPassword(user.password);
        },
        /** Hash only if changed to avoid double-hashing */
        beforeUpdate: async (user: User) => {
          if (user.changed('password')) {
            await user.setPassword(user.password);
          }
        },
        /** Support bulkCreate with { individualHooks: true } */
        beforeBulkCreate: async (users: User[], options) => {
          // Prefer individualHooks to keep logic centralized.
          if (!options.individualHooks) {
            for (const u of users) {
              if (u.changed('password') || !u.password.startsWith('$2')) {
                await u.setPassword(u.password);
              }
            }
          }
        },
      },
    }
  );

  return User;
}
